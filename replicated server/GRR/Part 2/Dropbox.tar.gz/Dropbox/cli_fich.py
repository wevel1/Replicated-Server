#!/usr/bin/env python3

import socket, sys, os
import szasar, time

SERVER = 'localhost'
PORT = 6012
ER_MSG = (
	"Correcto.",
	"Comando desconocido o inesperado.",
	"Usuario desconocido.",
	"Clave de paso o password incorrecto.",
	"Error al crear la lista de ficheros.",
	"El fichero no existe.",
	"Error al bajar el fichero.",
	"Un usuario anonimo no tiene permisos para esta operacion.",
	"El fichero es demasiado grande.",
	"Error al preparar el fichero para subirlo.",
	"Error al subir el fichero.",
	"Error al borrar el fichero." )

class Menu:
	List, Download, Upload, Delete, Exit = range( 1, 6 )
	Options = ( "Lista de ficheros", "Bajar fichero", "Subir fichero", "Borrar fichero", "Salir" )

	def operation():
		while 1:
			# Obtener el nombre del archivo.
			line = sys.stdin.readline()	#Cuando recibe un input finalizado en \n, lo guarda en line.
			if not line:
				continue
			else:
				operation = line


			# Obtener el numero, que nos indicará que tipo de operación se ha realizado (crear, borrar...)
			line = sys.stdin.readline()	#Cuando recibe un input finalizado en \n, lo guarda en line.
			if not line:
				continue
			else:
				filename = line	
			print("OPERATION - option: "+operation+"filename: "+filename)
			return operation,filename


def iserror( message ):
	if( message.startswith( "ER" ) ):
		code = int( message[2:] )
		print( ER_MSG[code] )
		return True
	else:
		return False

def int2bytes( n ):
	if n < 1 << 10:
		return str(n) + " B  "
	elif n < 1 << 20:
		return str(round( n / (1 << 10) ) ) + " KiB"
	elif n < 1 << 30:
		return str(round( n / (1 << 20) ) ) + " MiB"
	else:
		return str(round( n / (1 << 30) ) ) + " GiB"



if __name__ == "__main__":
	if len( sys.argv ) > 3:
		print( "Uso: {} [<servidor> [<puerto>]]".format( sys.argv[0] ) )
		exit( 2 )

	if len( sys.argv ) >= 2:
		SERVER = sys.argv[1]
	if len( sys.argv ) == 3:
		PORT = int( sys.argv[2])

	s = socket.socket( socket.AF_INET, socket.SOCK_STREAM )
	s.connect( (SERVER, PORT) )

	init = sys.stdin.readline() #Leemos el primer parametro que pasa inotify (un 1) para que no nos de problemas.
	print("El primer parametro leido antes de iniciar el analisis: " + init)
	
	while True:
		option, filename = Menu.operation()
		print("En el main, option: " + option + "y filename: "+ filename)

		if int(option) == Menu.Download:
			message = "{}{}\r\n".format( szasar.Command.Download, filename )
			s.sendall( message.encode( "ascii" ) )
			message = szasar.recvline( s ).decode ("ascii" )
			if iserror( message ):
				continue
			filesize = int( message[2:] )
			message = "{}\r\n".format( szasar.Command.Download2 )
			s.sendall( message.encode( "ascii" ) )
			message = szasar.recvline( s ).decode( "ascii" )
			if iserror( message ):
				continue
			filedata = szasar.recvall( s, filesize )
			print("tengo el filesize: " + filesize)
			try:
				with open( filename, "wb" ) as f:
					f.write( filedata )
			except:
				print( "No se ha podido guardar el fichero en disco." )
			else:
				print( "El fichero {} se ha descargado correctamente.".format( filename ) )

		elif int(option) == Menu.Upload:
			filename = os.path.join('local', str(filename))
			print("el filename ahora: " + filename)
			try:
				filesize = os.path.getsize( filename )
				print("tengo el filesize: " + filesize)
				with open( filename, "rb" ) as f:
					filedata = f.read()
			except:
				print( "No se ha podido acceder al fichero {}.".format( filename ) )
				continue

			message = "{}{}?{}\r\n".format( szasar.Command.Upload, filename, filesize )
			s.sendall( message.encode( "ascii" ) )
			message = szasar.recvline( s ).decode( "ascii" )
			if iserror( message ):
				continue

			message = "{}\r\n".format( szasar.Command.Upload2 )
			s.sendall( message.encode( "ascii" ) )
			s.sendall( filedata )
			message = szasar.recvline( s ).decode( "ascii" )
			if not iserror( message ):
				print( "El fichero {} se ha enviado correctamente.".format( filename ) )

		elif option == Menu.Delete:
			filename = input( "Indica el fichero que quieres borrar: " )
			message = "{}{}\r\n".format( szasar.Command.Delete, filename )
			s.sendall( message.encode( "ascii" ) )
			message = szasar.recvline( s ).decode( "ascii" )
			if not iserror( message ):
				print( "El fichero {} se ha borrado correctamente.".format( filename ) )

		elif option == Menu.Exit:
			message = "{}\r\n".format( szasar.Command.Exit )
			s.sendall( message.encode( "ascii" ) )
			message = szasar.recvline( s ).decode( "ascii" )
			break
	s.close()
